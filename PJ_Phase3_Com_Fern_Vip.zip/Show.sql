--Owner
select count(*) as Total_Index from Owner_
select * from Owner_

--Technical_Staff
select count(*) as Total_Index from Technical_Staff
select * from Technical_Staff

--Manager
select count(*) as Total_Index from Manager
select * from Manager

--Business_Analyst
select count(*) as Total_Index from Business_Analyst
select * from Business_Analyst

--Promotion
select count(*) as Total_Index from Promotion
select * from Promotion

--Technical_Issue
select count(*) as Total_Index from Technical_Issue
select * from Technical_Issue

--Credit_Card
select count(*) as Total_Index from Credit_Card
select * from Credit_Card

--Debit_Card
select count(*) as Total_Index from Debit_Card
select * from Debit_Card

--Book_Bank
select count(*) as Total_Index from Book_Bank
select * from Book_Bank

--Wallet
select count(*) as Total_Index from Wallet
select * from Wallet

--Money_Transfer
select count(*) as Total_Index from Money_Transfer
select * from Money_Transfer

--Top_Up_by_Using_Credit_Card
select count(*) as Total_Index from top_up_from_credit
select * from top_up_from_credit

--Top_Up_by_Using_Debit_Card
select count(*) as Total_Index from top_up_from_debit
select * from top_up_from_debit

--Top_Up_by_Using_Book_Bank
select count(*) as Total_Index from top_up_from_bank
select * from top_up_from_bank